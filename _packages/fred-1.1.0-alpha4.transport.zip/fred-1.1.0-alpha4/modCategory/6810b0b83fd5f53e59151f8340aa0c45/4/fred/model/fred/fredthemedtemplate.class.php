<?php
/**
 * @property int $theme
 * @property int $template
 * @property int $default_blueprint
 * 
 * @property FredTheme $Theme
 * @property modTemplate $Template
 * 
 * @package fred
 */
class FredThemedTemplate extends xPDOObject {}