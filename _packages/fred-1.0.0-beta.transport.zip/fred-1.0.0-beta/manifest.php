<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'The MIT License (MIT)

Copyright (c) 2016 Liad Yosef

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => '---------------------------------------
Fred
---------------------------------------
Version: 0.1.3-alpha
Author: John Peca <john@modx.com>
---------------------------------------',
    'changelog' => 'Changelog for Fred.

',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'eca58cc73002f7563592dce1cdbf8f99',
      'native_key' => 'fred',
      'filename' => 'modNamespace/9c191c3ec328eb5e746a3b0bd37e1c5c.vehicle',
      'namespace' => 'fred',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a51f06a7808b1d3e3026a511d6be16bf',
      'native_key' => 'fred.elements_category_id',
      'filename' => 'modSystemSetting/287f4c803ce0186ab83a27be7f3c5fc2.vehicle',
      'namespace' => 'fred',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '354d0cd38239da462e8fe7dc5b709733',
      'native_key' => 'fred.template_ids',
      'filename' => 'modSystemSetting/b4ce1612828551cbd1e85b1b143ccb21.vehicle',
      'namespace' => 'fred',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bee3d4278c0de0f9d674bdb1a4239ea6',
      'native_key' => 'fred.launcher_position',
      'filename' => 'modSystemSetting/55c6eb5b8b2c1ee87dad8d6ae1b73f8b.vehicle',
      'namespace' => 'fred',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c916c69f72f7353fa0bf1618b5abc4dd',
      'native_key' => 'fred.icon_editor',
      'filename' => 'modSystemSetting/712d5bb44b8dd05e44e80bdaa5dd6608.vehicle',
      'namespace' => 'fred',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '14267159648f7f627ccaf7232b549bfb',
      'native_key' => 'fred.image_editor',
      'filename' => 'modSystemSetting/45d852224a80f08bf4b47a64b5a6ca47.vehicle',
      'namespace' => 'fred',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '93552bf37c62829af25a8ab0c371cde1',
      'native_key' => 'fred.rte',
      'filename' => 'modSystemSetting/699d9497662baf251ddb4ed9a92e65ba.vehicle',
      'namespace' => 'fred',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd19608f20b3608d0bd3b54d9a9d0dc40',
      'native_key' => 'fred.rte_config',
      'filename' => 'modSystemSetting/88dce37335d29fdec197834acf3b28b3.vehicle',
      'namespace' => 'fred',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a00d451d58500d68f54c5de235270376',
      'native_key' => 'fred.element_group_sort',
      'filename' => 'modSystemSetting/70abc3b83734cd3cc3936402d04fcf95.vehicle',
      'namespace' => 'fred',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fd37f5fcbb89d65949100d632a6200cb',
      'native_key' => 'fred.default_element',
      'filename' => 'modSystemSetting/cfa7b999c020373cc25427b153ce7c58.vehicle',
      'namespace' => 'fred',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'c0f9d95c55e6920b29fadd18da13ad2a',
      'native_key' => NULL,
      'filename' => 'modCategory/df17213920a4f24b7d9ebc4b76995b3f.vehicle',
      'namespace' => 'fred',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'a8bf9dfc823be6a7c812c65f48a2621e',
      'native_key' => 'fred.refresh',
      'filename' => 'modMenu/606b2ac44a0e30977d93a9034253b21f.vehicle',
      'namespace' => 'fred',
    ),
  ),
);