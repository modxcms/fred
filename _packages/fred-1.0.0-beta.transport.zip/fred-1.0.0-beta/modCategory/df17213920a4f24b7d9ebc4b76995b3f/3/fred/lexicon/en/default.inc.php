<?php
/*
 * This file is part of the Fred package.
 *
 * Copyright (c) MODX, LLC
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

/**
 * Default English Lexicon Entries for Fred
 *
 * @package fred
 * @subpackage lexicon
 */

$_lang['fred'] = 'Fred';

$_lang['fred.open_in_fred'] = 'Open In Fred';

$_lang['fred.refresh'] = 'Rebuild Fred Resources';
$_lang['fred.refresh_desc'] = 'Rebuild Resources using Fred Templates';
$_lang['fred.refresh_fail_resource'] = 'No Fred resources found to refresh';
$_lang['fred.refresh_fail_template'] = 'No Fred templates specified to refresh';
$_lang['fred.refresh_complete'] = 'Rebuild Completed';
$_lang['fred.refresh_id'] = 'Refreshing Resource ID [[+id]]';

$_lang['setting_fred.launcher_position'] = 'Position of Launcher';
$_lang['setting_fred.launcher_position_desc'] = 'Available values: bottom_left, bottom_right, top_left, top_right';
$_lang['setting_fred.elements_category_id'] = 'Element\'s Category ID';
$_lang['setting_fred.elements_category_id_desc'] = 'ID of Category to use as an element source.';
$_lang['setting_fred.element_group_sort'] = 'Element\'s Group Sort';
$_lang['setting_fred.element_group_sort_desc'] = 'Sort elements by name or rank';
$_lang['setting_fred.icon_editor'] = 'Icon Editor';
$_lang['setting_fred.icon_editor_desc'] = 'Editor to use for Icons';
$_lang['setting_fred.image_editor'] = 'Image Editor';
$_lang['setting_fred.image_editor_desc'] = 'Editor to use for Images';
$_lang['setting_fred.rte'] = 'Rich Text Editor';
$_lang['setting_fred.rte_desc'] = 'Editor to use for Rich Text areas';
$_lang['setting_fred.template_ids'] = 'Template IDs';
$_lang['setting_fred.template_ids_desc'] = 'Comma separated list of template IDs where Fred will init.';
$_lang['setting_fred.default_element'] = 'Default Element';
$_lang['setting_fred.default_element_desc'] = 'Set a default <b>element ID</b> and <b>target</b> for converting resources to Fred. E.g. 10|target';
