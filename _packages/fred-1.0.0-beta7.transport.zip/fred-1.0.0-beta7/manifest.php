<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'The MIT License (MIT)

Copyright (c) 2018 MODX, LLC

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.',
    'readme' => '---------------------------------------
Fred
---------------------------------------
Version: 1.0.0-beta7
Author: John Peca <john@modx.com>
---------------------------------------

UPGRADE NOTES
=======================================
-> beta7
If you defined media sources in option sets, element\'s markup or options override you\'ll need to adjust these from media source id to media source name ',
    'changelog' => 'Changelog for Fred.

1.0.0 beta7
==============
- Move elFinder\'s processors under core for better security
- Streamline elFinder buttons shown
- Create a Media Source on Fred installation: /assets
- Add a tab to the Manager component for managing the Media Sources available to Fred
- Fix toggle option setting control when the default value was set to true
- Change referencing Media Sources by ID to Name in option sets and Element markup

1.0.0 beta6
==============
- Add theme directory for theme\'s assets
- Use new placeholder {{theme_dir}} when generating elements & blueprints images
- Add placeholder for templates & chunk [[++fred.theme_dir]] to reference theme directory
- Add Build theme action (creates a transport package from theme)
- Consolidate tabs in the CMP
- Generate screenshot for complete blueprint from page preview (instead of from Fred\'s view)
- Remove deprecated system settings
- Add help buttons to CMP and frontend (under "More" sidebar)
- Remove theme-template relation when template is deleted
- When deleting theme, give an option to delete theme directory
- When duplicating theme, give an options to duplicate theme\'s objects and theme directory
- Fix selecting option set from current theme in element\'s quick update window and update panel 

1.0.0 beta5
==============
- Lower dependencies to support PHP 5.6+
- Security fixes

1.0.0 beta4
==============
- Add CMP for Elements, RTE Configs, Option Sets, Themes
- Add UUID for elements, element categories, blueprints and blueprint categories
- Make blueprint\'s & element\'s image not required and fill it with placeholder image if empty
- TVs as a target & in Page Settings

1.0.0 beta3
==============
- Add CMP for Blueprints
- Add blueprints
- Add default image for elements, if none is set

1.0.0 beta2
==============
- Prevent child blocks from remaining active on scroll
- Add context_key check to site tree
- Fixed foreach warning on RenderContent and LoadContent
- Update documentation
- Add ru lexicon
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'd13182ee2ccbeac1b14f0991aedb24a7',
      'native_key' => 'fred',
      'filename' => 'modNamespace/c20a0eb73baf4a6a4331be775ae3c1e5.vehicle',
      'namespace' => 'fred',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fa570109a820e3cf49128d5e686e7139',
      'native_key' => 'fred.launcher_position',
      'filename' => 'modSystemSetting/3a21b5c4960ce9790b0c6b1811d0b4a3.vehicle',
      'namespace' => 'fred',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9d1977b4763f7a3ff1c37470cdab2d33',
      'native_key' => 'fred.icon_editor',
      'filename' => 'modSystemSetting/016a816b9b72335223f2bc08a2221685.vehicle',
      'namespace' => 'fred',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e789a0e1bafa343e7bf26145dc50a04b',
      'native_key' => 'fred.image_editor',
      'filename' => 'modSystemSetting/2ecc8c86c092551de42a622e676925ad.vehicle',
      'namespace' => 'fred',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2d99d9782b5c71de112cad9d2fe0266f',
      'native_key' => 'fred.rte',
      'filename' => 'modSystemSetting/9030f4de98f88da4f203ac467a51148c.vehicle',
      'namespace' => 'fred',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4a1eae779d70d11c07a835e4b29e3a5e',
      'native_key' => 'fred.element_group_sort',
      'filename' => 'modSystemSetting/b22022a83cac4025ce582c6c41116c99.vehicle',
      'namespace' => 'fred',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '980b4afc3fdfdfcb7a171a659e2ee30d',
      'native_key' => 'fred.blueprint_category_sort',
      'filename' => 'modSystemSetting/7257be9bd9d3ddc63c900d8787e5f324.vehicle',
      'namespace' => 'fred',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4ce341bb4ce448e6aefe18a842ac648a',
      'native_key' => 'fred.blueprint_sort',
      'filename' => 'modSystemSetting/a134389e95aeac1ed9f450700109e369.vehicle',
      'namespace' => 'fred',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fc8f7b70263ad6306c6a804f89fdbe6f',
      'native_key' => 'fred.default_element',
      'filename' => 'modSystemSetting/7e5e8176423ad1f8a148ba9d2b265509.vehicle',
      'namespace' => 'fred',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '86ada28d9c4c3582b6ef04d7b6bd8a75',
      'native_key' => NULL,
      'filename' => 'modCategory/bcd21f423dccec3ff7c37ec1e2c820b0.vehicle',
      'namespace' => 'fred',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'f17068d7905c309b2289140e3c270d9a',
      'native_key' => 'fred.menu.fred',
      'filename' => 'modMenu/74ef0730f1d12cf0df704d8431660c70.vehicle',
      'namespace' => 'fred',
    ),
  ),
);