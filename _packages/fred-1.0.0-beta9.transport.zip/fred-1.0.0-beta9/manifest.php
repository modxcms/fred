<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'The MIT License (MIT)

Copyright (c) 2018 MODX, LLC

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.',
    'readme' => '---------------------------------------
Fred
---------------------------------------
Version: 1.0.0-beta9
Author: John Peca <john@modx.com>
---------------------------------------

UPGRADE NOTES
=======================================
-> beta7
If you defined media sources in option sets, element\'s markup or options override you\'ll need to adjust these from media source id to media source name ',
    'changelog' => 'Changelog for Fred.

1.0.0 beta9
==============
- Fred now supports Permissions and Policies, ticking off the last big 1.0 feature checklist item. Time to thoroughly work over every bit of Fred ahead of its initial public release! 
- The width of the toolbar on small Elements hid important icons. Now it doesn\'t. 
- While mildly entertaining at first, the flashing cycles when hovering the parent Element of nested ones quickly becomes annoying. Fixed.
- You get to see the magical preview soon after clicking the button when generating full-page Blueprints. So much for delayed gratification. 
- Validate the name, version, and release when building a Theme, because themes are cool and it\'s the right thing to do.
- Check `list` policy on media sources so people can\'t rearrange the root-level file system for you.
- Sign every XHR call so that less than scrupulous people don\'t edit—or remove—your site for you.
- Display an error message that explains why trying to download a theme without a transport package doesn\'t work so well.

1.0.0 beta8
==============
- Now with 100% more German. Danke für die Übersetzung.
- Fix HTML generation when saving Fred Resource from the Manager,  which didn\'t work and was a bummer. Now it\'s not.
- Show a loading icon when generating Blueprint screenshots. This helps calm user anxiety over "Didn\'t I just push that button? …" as it can take a few seconds when doing full-page Blueprints.
- Duplicating an image that saved to a TV caused an infinite loop. Inception is good for movies, not for software, so we fixed that.
- Fix toggling fred and fredReadOnly attributes from in the Media Source tab of the Manager page because it\'s the right thing to do.

1.0.0 beta7
==============
- Move elFinder\'s processors under core for better security
- Streamline elFinder buttons shown
- Create a Media Source on Fred installation: /assets
- Add a tab to the Manager component for managing the Media Sources available to Fred
- Fix toggle option setting control when the default value was set to true
- Change referencing Media Sources by ID to Name in option sets and Element markup

1.0.0 beta6
==============
- Add theme directory for theme\'s assets
- Use new placeholder {{theme_dir}} when generating elements & blueprints images
- Add placeholder for templates & chunk [[++fred.theme_dir]] to reference theme directory
- Add Build theme action (creates a transport package from theme)
- Consolidate tabs in the CMP
- Generate screenshot for complete blueprint from page preview (instead of from Fred\'s view)
- Remove deprecated system settings
- Add help buttons to CMP and frontend (under "More" sidebar)
- Remove theme-template relation when template is deleted
- When deleting theme, give an option to delete theme directory
- When duplicating theme, give an options to duplicate theme\'s objects and theme directory
- Fix selecting option set from current theme in element\'s quick update window and update panel 

1.0.0 beta5
==============
- Lower dependencies to support PHP 5.6+
- Security fixes

1.0.0 beta4
==============
- Add CMP for Elements, RTE Configs, Option Sets, Themes
- Add UUID for elements, element categories, blueprints and blueprint categories
- Make blueprint\'s & element\'s image not required and fill it with placeholder image if empty
- TVs as a target & in Page Settings

1.0.0 beta3
==============
- Add CMP for Blueprints
- Add blueprints
- Add default image for elements, if none is set

1.0.0 beta2
==============
- Prevent child blocks from remaining active on scroll
- Add context_key check to site tree
- Fixed foreach warning on RenderContent and LoadContent
- Update documentation
- Add ru lexicon
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '228386f4267c44337e39013204c1bcfd',
      'native_key' => 'fred',
      'filename' => 'modNamespace/2385a6672f401347f1554ed83fde5177.vehicle',
      'namespace' => 'fred',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '234634e21218c7e3bc9a76ddae80a69f',
      'native_key' => 'fred.launcher_position',
      'filename' => 'modSystemSetting/fadec80cb5bc3b33a374b2e806cc599c.vehicle',
      'namespace' => 'fred',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dd52959ea61294684959baf2bcc9e97a',
      'native_key' => 'fred.icon_editor',
      'filename' => 'modSystemSetting/e8c52b40bd89de2f557b91d7ab15cdd2.vehicle',
      'namespace' => 'fred',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eadff79dd17c7b6b51abc43f70b2d759',
      'native_key' => 'fred.image_editor',
      'filename' => 'modSystemSetting/06ce0849fc12ebff683091d95ff25822.vehicle',
      'namespace' => 'fred',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2806b9cdc51a604ad350449a5762351d',
      'native_key' => 'fred.rte',
      'filename' => 'modSystemSetting/dfbaa659d9a57745718a35a5249e55e9.vehicle',
      'namespace' => 'fred',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f9170404ebbd844a6c5e8f1cd4891af5',
      'native_key' => 'fred.element_group_sort',
      'filename' => 'modSystemSetting/74339b2d2ade489306d82806c1b40220.vehicle',
      'namespace' => 'fred',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1f79321fe270f3c85a266a997e67f9a2',
      'native_key' => 'fred.blueprint_category_sort',
      'filename' => 'modSystemSetting/8a4d220a8dc35ce181d9e11235d5dc3a.vehicle',
      'namespace' => 'fred',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4d291e46341d2e1088e781a387859737',
      'native_key' => 'fred.blueprint_sort',
      'filename' => 'modSystemSetting/c4afffd7bbddfeae27ecc6d6aaddcf81.vehicle',
      'namespace' => 'fred',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b6ae95892de4b562c58f48f530736832',
      'native_key' => 'fred.default_element',
      'filename' => 'modSystemSetting/953fa6d6388f3ad9b2120859e8849128.vehicle',
      'namespace' => 'fred',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8480ceaaca45d5a7c9445db6fc74db92',
      'native_key' => 'fred.secret',
      'filename' => 'modSystemSetting/32984729096aa6e131cd6d3173753cd0.vehicle',
      'namespace' => 'fred',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '1873810b4b39272034e5ccea21de5a00',
      'native_key' => NULL,
      'filename' => 'modCategory/c7a11819cf3417ab4cfc4b4cfa0f6e97.vehicle',
      'namespace' => 'fred',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'a3784791c350819c7b3ca78f0abac934',
      'native_key' => 'fred.menu.fred',
      'filename' => 'modMenu/41163b7f2ecb2ac7d9cd7048bcc3d1a7.vehicle',
      'namespace' => 'fred',
    ),
  ),
);