<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => '
The MIT License (MIT)

Copyright (c) 2018 MODX, LLC

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.',
    'readme' => '---------------------------------------
Fred
---------------------------------------
Version: 0.1.0
Author: John Peca <john@modx.com>
---------------------------------------',
    'changelog' => 'Changelog for Fred.

Fred 0.1.0
==============
- Initial release.',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '1d2a9b7a866ae4a16d3950129000a549',
      'native_key' => 'fred',
      'filename' => 'modNamespace/87e685d95b87aec1b7a7b7276b266a79.vehicle',
      'namespace' => 'fred',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f0678196e1cb7c8ec0b4a698b7e450ca',
      'native_key' => 'fred.elements_category_id',
      'filename' => 'modSystemSetting/cd827eee89caec4b811aad5351dd32c7.vehicle',
      'namespace' => 'fred',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5bdb1faeddfff5ac952f23a8198d7db5',
      'native_key' => 'fred.template_ids',
      'filename' => 'modSystemSetting/ae6912adfe0a0882fc5133c74bcebe02.vehicle',
      'namespace' => 'fred',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2c5a0ada2858a32dd28a16d6ae26a83e',
      'native_key' => 'fred.launcher_position',
      'filename' => 'modSystemSetting/7169c1df658e5505bdabaf8df4c33a9f.vehicle',
      'namespace' => 'fred',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '62b4c4ec2d1e33b7e91602587b5368a8',
      'native_key' => 'fred.icon_editor',
      'filename' => 'modSystemSetting/7ba92d9c1434015506185983abbbbf05.vehicle',
      'namespace' => 'fred',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e9a6838404c4ae0196aa5a17d2fb0c55',
      'native_key' => 'fred.image_editor',
      'filename' => 'modSystemSetting/c412c04a4143155e00edfde66a093626.vehicle',
      'namespace' => 'fred',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e305decc31cf6595df59631fe45df5ab',
      'native_key' => 'fred.rte',
      'filename' => 'modSystemSetting/07faa0713e786b445e0cf9180203c280.vehicle',
      'namespace' => 'fred',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '83cca618a93eae2de2f5126d8bfcecec',
      'native_key' => NULL,
      'filename' => 'modCategory/034c6e77ffd820757008de847c5621d5.vehicle',
      'namespace' => 'fred',
    ),
  ),
);