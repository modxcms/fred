<?php
/**
 * @package fred
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/fredelementrteconfig.class.php');
class FredElementRTEConfig_mysql extends FredElementRTEConfig {}
?>