<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'The MIT License (MIT)

Copyright (c) 2018 MODX, LLC

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.',
    'readme' => '---------------------------------------
Fred
---------------------------------------
Version: 1.0.0-beta10
Author: John Peca <john@modx.com>
---------------------------------------

UPGRADE NOTES
=======================================
-> beta7
If you defined media sources in option sets, element\'s markup or options override you\'ll need to adjust these from media source id to media source name ',
    'changelog' => 'Changelog for Fred.

1.0.0 beta10
============
- Supports multiple dropzones thanks to a new custom "Fred Dropzone" Template Variable. 
- A new element_sort system setting determines, shockingly, how Elements are sorted: either by their name or by a rank specified in the Manager component (previously was by ID). Defaults to name.
- Fred didn\'t allow using Snippets in image tag src attributes. Now it does making @reikotec at least 42% more happy. You\'re welcome! 
- Fixed an annoying oversight that broke how Fred-managed content rendered after saving a page in the Manager (which was not very well at all).
- Now you can clone, delete, publish/unpublish and create child pages from the Fred sidebar menu Site option. Click a page name to see the available options. 

1.0.0 beta9
==============
- Fred now supports Permissions and Policies, ticking off the last big 1.0 feature checklist item. Time to thoroughly work over every bit of Fred ahead of its initial public release! 
- The width of the toolbar on small Elements hid important icons. Now it doesn\'t. 
- While mildly entertaining at first, the flashing cycles when hovering the parent Element of nested ones quickly becomes annoying. Fixed.
- You get to see the magical preview soon after clicking the button when generating full-page Blueprints. So much for delayed gratification. 
- Validate the name, version, and release when building a Theme, because themes are cool and it\'s the right thing to do.
- Check `list` policy on media sources so people can\'t rearrange the root-level file system for you.
- Sign every XHR call so that less than scrupulous people don\'t edit—or remove—your site for you.
- Display an error message that explains why trying to download a theme without a transport package doesn\'t work so well.

1.0.0 beta8
==============
- Now with 100% more German. Danke für die Übersetzung.
- Fix HTML generation when saving Fred Resource from the Manager,  which didn\'t work and was a bummer. Now it\'s not.
- Show a loading icon when generating Blueprint screenshots. This helps calm user anxiety over "Didn\'t I just push that button? …" as it can take a few seconds when doing full-page Blueprints.
- Duplicating an image that saved to a TV caused an infinite loop. Inception is good for movies, not for software, so we fixed that.
- Fix toggling fred and fredReadOnly attributes from in the Media Source tab of the Manager page because it\'s the right thing to do.

1.0.0 beta7
==============
- Move elFinder\'s processors under core for better security
- Streamline elFinder buttons shown
- Create a Media Source on Fred installation: /assets
- Add a tab to the Manager component for managing the Media Sources available to Fred
- Fix toggle option setting control when the default value was set to true
- Change referencing Media Sources by ID to Name in option sets and Element markup

1.0.0 beta6
==============
- Add theme directory for theme\'s assets
- Use new placeholder {{theme_dir}} when generating elements & blueprints images
- Add placeholder for templates & chunk [[++fred.theme_dir]] to reference theme directory
- Add Build theme action (creates a transport package from theme)
- Consolidate tabs in the CMP
- Generate screenshot for complete blueprint from page preview (instead of from Fred\'s view)
- Remove deprecated system settings
- Add help buttons to CMP and frontend (under "More" sidebar)
- Remove theme-template relation when template is deleted
- When deleting theme, give an option to delete theme directory
- When duplicating theme, give an options to duplicate theme\'s objects and theme directory
- Fix selecting option set from current theme in element\'s quick update window and update panel 

1.0.0 beta5
==============
- Lower dependencies to support PHP 5.6+
- Security fixes

1.0.0 beta4
==============
- Add CMP for Elements, RTE Configs, Option Sets, Themes
- Add UUID for elements, element categories, blueprints and blueprint categories
- Make blueprint\'s & element\'s image not required and fill it with placeholder image if empty
- TVs as a target & in Page Settings

1.0.0 beta3
==============
- Add CMP for Blueprints
- Add blueprints
- Add default image for elements, if none is set

1.0.0 beta2
==============
- Prevent child blocks from remaining active on scroll
- Add context_key check to site tree
- Fixed foreach warning on RenderContent and LoadContent
- Update documentation
- Add ru lexicon
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '859a3520b2e2f301244064aa82fb4094',
      'native_key' => 'fred',
      'filename' => 'modNamespace/ddedcf25ca52c44738f33a1563c264c3.vehicle',
      'namespace' => 'fred',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9cbfe77a360413ec372633cd1b3dc056',
      'native_key' => 'fred.launcher_position',
      'filename' => 'modSystemSetting/352d0c5f7845281441124f2d9fefa07a.vehicle',
      'namespace' => 'fred',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a0b2ea4988980c3de5aec334e4f183a4',
      'native_key' => 'fred.icon_editor',
      'filename' => 'modSystemSetting/e546373486c84f3cfc11dc7d7c265c73.vehicle',
      'namespace' => 'fred',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '962133bc524c742e5ad46da9a9331834',
      'native_key' => 'fred.image_editor',
      'filename' => 'modSystemSetting/a9bbc63bc74eaa6f9f1509996305ec31.vehicle',
      'namespace' => 'fred',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3cc0d2314edbd91befa3ffad39e9a291',
      'native_key' => 'fred.rte',
      'filename' => 'modSystemSetting/cbce9741cf7aa770a7280a9febabd8ae.vehicle',
      'namespace' => 'fred',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd28fbc6e8110d066146b8e9cf1d1dcc8',
      'native_key' => 'fred.element_group_sort',
      'filename' => 'modSystemSetting/79037acb44aa4c80443b5875b7aa0948.vehicle',
      'namespace' => 'fred',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6cf423f1a664a03d35999158a4854094',
      'native_key' => 'fred.element_sort',
      'filename' => 'modSystemSetting/d74be55637cc2ae1948cdd0d5110b11a.vehicle',
      'namespace' => 'fred',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3bbe6f749d33ee9686ca6b3405f39d8e',
      'native_key' => 'fred.blueprint_category_sort',
      'filename' => 'modSystemSetting/c84a08c224e0096797f5b6c48e7c2e3f.vehicle',
      'namespace' => 'fred',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7b4a1a7c5ceadd97266081bd1dcbd73d',
      'native_key' => 'fred.blueprint_sort',
      'filename' => 'modSystemSetting/a568a7aa8e2e5089458c93b363de0397.vehicle',
      'namespace' => 'fred',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '047b50b8e6822ed9058087ae99754981',
      'native_key' => 'fred.default_element',
      'filename' => 'modSystemSetting/aa474f428c4c87e98cc211789d3498db.vehicle',
      'namespace' => 'fred',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '075305e2574edb1c773ad3978c4757b7',
      'native_key' => 'fred.secret',
      'filename' => 'modSystemSetting/84965d0d89c6239c2c4b19a45730e054.vehicle',
      'namespace' => 'fred',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'a756f9548325b878babc7d5c0473efa3',
      'native_key' => NULL,
      'filename' => 'modCategory/052b8e91eeebccc30c81c20d86dd3fb9.vehicle',
      'namespace' => 'fred',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'e667fc4b9451b087a96c46f5e1da78ab',
      'native_key' => 'fred.menu.fred',
      'filename' => 'modMenu/c3e0249ac906357891e0a90557d73738.vehicle',
      'namespace' => 'fred',
    ),
  ),
);