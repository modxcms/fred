<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'FredBlueprintCategory',
    1 => 'FredBlueprint',
    2 => 'FredElementCategory',
    3 => 'FredElementOptionSet',
    4 => 'FredElementRTEConfig',
    5 => 'FredElement',
    6 => 'FredTheme',
  ),
  'xPDOObject' => 
  array (
    0 => 'FredThemedTemplate',
    1 => 'FredCache',
  ),
);