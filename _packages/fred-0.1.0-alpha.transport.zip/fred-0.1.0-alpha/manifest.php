<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'The MIT License (MIT)

Copyright (c) 2018 MODX, LLC

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.',
    'readme' => '---------------------------------------
Fred
---------------------------------------
Version: 0.1.0
Author: John Peca <john@modx.com>
---------------------------------------',
    'changelog' => 'Changelog for Fred.

Fred 0.1.0
==============
- Initial release.',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '09826f1bc58722fa81be429433d10298',
      'native_key' => 'fred',
      'filename' => 'modNamespace/3db052f042efa432775a20caf8401e4b.vehicle',
      'namespace' => 'fred',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '207e3d92a1afb6491a791743a3961812',
      'native_key' => 'fred.elements_category_id',
      'filename' => 'modSystemSetting/15f3709bb0958599a464fade8c653a0b.vehicle',
      'namespace' => 'fred',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1cd39948b0f6bd01ddb115c8a8b8a31c',
      'native_key' => 'fred.template_ids',
      'filename' => 'modSystemSetting/cc8bb5a9207ad6aba3facdb0a35cd1d4.vehicle',
      'namespace' => 'fred',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b155cc5594c16881500a0e0ffd8d8ec1',
      'native_key' => 'fred.launcher_position',
      'filename' => 'modSystemSetting/4351223dde670e13a205cbb51437b45a.vehicle',
      'namespace' => 'fred',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cd259aaba0c95829c5e3b7bc1c681681',
      'native_key' => 'fred.icon_editor',
      'filename' => 'modSystemSetting/7230b2c184b6038428617ff219980026.vehicle',
      'namespace' => 'fred',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2a927a3798832bd8408d70dd71295fa7',
      'native_key' => 'fred.image_editor',
      'filename' => 'modSystemSetting/e7296ee9cca7edcea1382d93eb0be36e.vehicle',
      'namespace' => 'fred',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fa07f83050c585d7fabd6d5526931227',
      'native_key' => 'fred.rte',
      'filename' => 'modSystemSetting/61ab19c325df03f0400021479e7cbf27.vehicle',
      'namespace' => 'fred',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'aa94b8a721beb7f5bffefb6584babc05',
      'native_key' => NULL,
      'filename' => 'modCategory/0a55041d6c4a741328c62312d767e8bc.vehicle',
      'namespace' => 'fred',
    ),
  ),
);