<?php

require_once 'init.php';

$ajax = new \Fred\Endpoint\Ajax($fred);
$ajax->run();