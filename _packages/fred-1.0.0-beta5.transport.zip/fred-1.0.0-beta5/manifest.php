<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'The MIT License (MIT)

Copyright (c) 2018 MODX, LLC

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.',
    'readme' => '---------------------------------------
Fred
---------------------------------------
Version: 1.0.0-beta5
Author: John Peca <john@modx.com>
---------------------------------------',
    'changelog' => 'Changelog for Fred.

1.0.0 beta5
==============
- Lower dependencies to support PHP 5.6+
- Security fixes

1.0.0 beta4
==============
- Add CMP for Elements, RTE Configs, Option Sets, Themes
- Add UUID for elements, element categories, blueprints and blueprint categories
- Make blueprint\'s & element\'s image not required and fill it with placeholder image if empty
- TVs as a target & in Page Settings

1.0.0 beta3
==============
- Add CMP for Blueprints
- Add blueprints
- Add default image for elements, if none is set

1.0.0 beta2
==============
- Prevent child blocks from remaining active on scroll
- Add context_key check to site tree
- Fixed foreach warning on RenderContent and LoadContent
- Update documentation
- Add ru lexicon
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '3f6bc9a11f0ba701b8a55d569cf2d44a',
      'native_key' => 'fred',
      'filename' => 'modNamespace/0a52d66f9f18318f5a0198d93e466a6f.vehicle',
      'namespace' => 'fred',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '20036ca2ac761c20436e4297a2492d70',
      'native_key' => 'fred.elements_category_id',
      'filename' => 'modSystemSetting/f94209a1e57b28a7bc3a30c027a46206.vehicle',
      'namespace' => 'fred',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bdcde457472d57339625e95faa028151',
      'native_key' => 'fred.template_ids',
      'filename' => 'modSystemSetting/37e7498352ed8940eb38ab6e9fbc4f7f.vehicle',
      'namespace' => 'fred',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5e2c9d21588624537e8f3ffecee22949',
      'native_key' => 'fred.launcher_position',
      'filename' => 'modSystemSetting/7c7c9bae4f747bd2897eeed6f8e4357a.vehicle',
      'namespace' => 'fred',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '38d512a4646682e760e6270c91e197d1',
      'native_key' => 'fred.icon_editor',
      'filename' => 'modSystemSetting/a8c7e7eec91e210a57801b0fd1971267.vehicle',
      'namespace' => 'fred',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cdf5a7c7f3e8b0c60b4b05a0a79b64ce',
      'native_key' => 'fred.image_editor',
      'filename' => 'modSystemSetting/545531226b6c6060187430c4b5efb66c.vehicle',
      'namespace' => 'fred',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0ff8f6ed321ed5acf7e383f2552f057c',
      'native_key' => 'fred.rte',
      'filename' => 'modSystemSetting/d1559b0ca9b290a926922755cd378094.vehicle',
      'namespace' => 'fred',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '80ee4c33d688e55c24899729d904ff8f',
      'native_key' => 'fred.rte_config',
      'filename' => 'modSystemSetting/d727a26111b4435077a155e7a2f51464.vehicle',
      'namespace' => 'fred',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ef08779e03b9af2c68de0a2aa1e729d6',
      'native_key' => 'fred.element_group_sort',
      'filename' => 'modSystemSetting/bf2843659747d735e734ddfaafadbd99.vehicle',
      'namespace' => 'fred',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '804a4e524528beeffbf95141a8e956be',
      'native_key' => 'fred.blueprint_category_sort',
      'filename' => 'modSystemSetting/caba3fc4c4755d131b31e04bcc884468.vehicle',
      'namespace' => 'fred',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a1aef875aa0c0a5f3ba71e9727f8740d',
      'native_key' => 'fred.blueprint_sort',
      'filename' => 'modSystemSetting/7bbb24ccc841bb42f648d764788a2318.vehicle',
      'namespace' => 'fred',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dc107e1c42fc230207cd82898dfb365b',
      'native_key' => 'fred.default_element',
      'filename' => 'modSystemSetting/6486decb4ae2858d28fc48c64565aef7.vehicle',
      'namespace' => 'fred',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6a9d5dd7082049dbfd639d29c3c8c97d',
      'native_key' => 'fred.generated_images_path',
      'filename' => 'modSystemSetting/878ea1d1df26d041db92dc31c7462920.vehicle',
      'namespace' => 'fred',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aee9a5a74e2fb7bf537eb6dfe3481135',
      'native_key' => 'fred.generated_images_url',
      'filename' => 'modSystemSetting/433f6aedbb69ccea34f2172a9d6426b2.vehicle',
      'namespace' => 'fred',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'fe139575cea8eba72a2bdd7a4196e50f',
      'native_key' => NULL,
      'filename' => 'modCategory/63b5439a04222ed9b9f59f714624929a.vehicle',
      'namespace' => 'fred',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '8a4f29d98716f10af73714d3acd1434b',
      'native_key' => 'fred.menu.fred',
      'filename' => 'modMenu/70adea01b274badbc3a57b6dcd04f213.vehicle',
      'namespace' => 'fred',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '6903912169732142a36cb034fe4b1752',
      'native_key' => 'fred.menu.refresh',
      'filename' => 'modMenu/9d515efd048b9350bacffd58b1eb5f58.vehicle',
      'namespace' => 'fred',
    ),
  ),
);