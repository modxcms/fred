<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'The MIT License (MIT)

Copyright (c) 2016 Liad Yosef

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => '---------------------------------------
Fred
---------------------------------------
Version: 0.1.3-alpha
Author: John Peca <john@modx.com>
---------------------------------------',
    'changelog' => 'Changelog for Fred.

1.0.0 beta2
==============
- Prevent child blocks from remaining active on scroll
- Add context_key check to site tree
- Fixed foreach warning on RenderContent and LoadContent
- Update documentation
- Add ru lexicon
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'e35af4f6dd91377d03f62aa233d2a30d',
      'native_key' => 'fred',
      'filename' => 'modNamespace/9dbdefe335d81f7640c043027512e7d0.vehicle',
      'namespace' => 'fred',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7320b2431a5b3cdadd4096e1cc7f5ac7',
      'native_key' => 'fred.elements_category_id',
      'filename' => 'modSystemSetting/e0aeab4bb745092b41d780829e783be9.vehicle',
      'namespace' => 'fred',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '826e57b852caf61b8843f97cf70d1954',
      'native_key' => 'fred.template_ids',
      'filename' => 'modSystemSetting/8ebb4e0e866128bf4126bfab63a26ed4.vehicle',
      'namespace' => 'fred',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '978cf374cde4801448824d8305e23750',
      'native_key' => 'fred.launcher_position',
      'filename' => 'modSystemSetting/d67a5060e67cd159c6c04b80bbb045ed.vehicle',
      'namespace' => 'fred',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0590677a560f0eea03cb86de3bb1a63c',
      'native_key' => 'fred.icon_editor',
      'filename' => 'modSystemSetting/13a5aa9bd7e96fb5e6e0c568d7302adf.vehicle',
      'namespace' => 'fred',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '390e8661ea909a994d7f40db4e267dd6',
      'native_key' => 'fred.image_editor',
      'filename' => 'modSystemSetting/3c48b061977244f8446be8b587d13016.vehicle',
      'namespace' => 'fred',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '023b3ab6cbbd92ea17203d5e61e8d65a',
      'native_key' => 'fred.rte',
      'filename' => 'modSystemSetting/4684ad07b10435e94c3b04aa4ff0df6e.vehicle',
      'namespace' => 'fred',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c5b8c43aafd9d0f714dd9e1deac47829',
      'native_key' => 'fred.rte_config',
      'filename' => 'modSystemSetting/b6ee74849107148397e08fb77e947706.vehicle',
      'namespace' => 'fred',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '058b9f0db9174ce03e545102b4b9f2a1',
      'native_key' => 'fred.element_group_sort',
      'filename' => 'modSystemSetting/832f074bdb42efa59ac3290d51872150.vehicle',
      'namespace' => 'fred',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '26073463ee3d63f1438a5ba1748592fa',
      'native_key' => 'fred.default_element',
      'filename' => 'modSystemSetting/741c7d03d7dd3361d9e002856bb15eb5.vehicle',
      'namespace' => 'fred',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '8dd5dffa2387688d181124f0e0dc5a7a',
      'native_key' => NULL,
      'filename' => 'modCategory/e9a9421feec7f2206b3d815c89d11985.vehicle',
      'namespace' => 'fred',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '813dac23af0178c9029a15ffc4f95c67',
      'native_key' => 'fred.refresh',
      'filename' => 'modMenu/432f4e4195091613dc9c0dad751a22fc.vehicle',
      'namespace' => 'fred',
    ),
  ),
);