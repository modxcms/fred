<?php
/**
 * @package fred
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/fredelementcategory.class.php');
class FredElementCategory_mysql extends FredElementCategory {}
?>