<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'The MIT License (MIT)

Copyright (c) 2018 MODX, LLC

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.',
    'readme' => '---------------------------------------
Fred
---------------------------------------
Version: 1.0.0-beta8
Author: John Peca <john@modx.com>
---------------------------------------

UPGRADE NOTES
=======================================
-> beta7
If you defined media sources in option sets, element\'s markup or options override you\'ll need to adjust these from media source id to media source name ',
    'changelog' => 'Changelog for Fred.

1.0.0 beta8
==============
- Now with 100% more German. Danke für die Übersetzung.
- Fix HTML generation when saving Fred Resource from the Manager,  which didn\'t work and was a bummer. Now it\'s not.
- Show a loading icon when generating Blueprint screenshots. This helps calm user anxiety over "Didn\'t I just push that button? …" as it can take a few seconds when doing full-page Blueprints.
- Duplicating an image that saved to a TV caused an infinite loop. Inception is good for movies, not for software, so we fixed that.
- Fix toggling fred and fredReadOnly attributes from in the Media Source tab of the Manager page because it\'s the right thing to do.

1.0.0 beta7
==============
- Move elFinder\'s processors under core for better security
- Streamline elFinder buttons shown
- Create a Media Source on Fred installation: /assets
- Add a tab to the Manager component for managing the Media Sources available to Fred
- Fix toggle option setting control when the default value was set to true
- Change referencing Media Sources by ID to Name in option sets and Element markup

1.0.0 beta6
==============
- Add theme directory for theme\'s assets
- Use new placeholder {{theme_dir}} when generating elements & blueprints images
- Add placeholder for templates & chunk [[++fred.theme_dir]] to reference theme directory
- Add Build theme action (creates a transport package from theme)
- Consolidate tabs in the CMP
- Generate screenshot for complete blueprint from page preview (instead of from Fred\'s view)
- Remove deprecated system settings
- Add help buttons to CMP and frontend (under "More" sidebar)
- Remove theme-template relation when template is deleted
- When deleting theme, give an option to delete theme directory
- When duplicating theme, give an options to duplicate theme\'s objects and theme directory
- Fix selecting option set from current theme in element\'s quick update window and update panel 

1.0.0 beta5
==============
- Lower dependencies to support PHP 5.6+
- Security fixes

1.0.0 beta4
==============
- Add CMP for Elements, RTE Configs, Option Sets, Themes
- Add UUID for elements, element categories, blueprints and blueprint categories
- Make blueprint\'s & element\'s image not required and fill it with placeholder image if empty
- TVs as a target & in Page Settings

1.0.0 beta3
==============
- Add CMP for Blueprints
- Add blueprints
- Add default image for elements, if none is set

1.0.0 beta2
==============
- Prevent child blocks from remaining active on scroll
- Add context_key check to site tree
- Fixed foreach warning on RenderContent and LoadContent
- Update documentation
- Add ru lexicon
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '4a751a378c78821877e14054fc560f41',
      'native_key' => 'fred',
      'filename' => 'modNamespace/f2429002ba602e7f16e8adc657d34134.vehicle',
      'namespace' => 'fred',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1a60cea89bd48f9d1fd6fffa9f58cbad',
      'native_key' => 'fred.launcher_position',
      'filename' => 'modSystemSetting/5319368621f5b30afef6c144635293a1.vehicle',
      'namespace' => 'fred',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '97e503d47afafdfc3c5157279cd6a2a3',
      'native_key' => 'fred.icon_editor',
      'filename' => 'modSystemSetting/4296457f851e6a44ddc300c8458ed6c8.vehicle',
      'namespace' => 'fred',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '681b5529c319c3b97a432aeb3fcbb6ec',
      'native_key' => 'fred.image_editor',
      'filename' => 'modSystemSetting/b43f1f192ccc92b747ae0c288819d4fd.vehicle',
      'namespace' => 'fred',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b82e0ea963f0b3132613a5bc174b213c',
      'native_key' => 'fred.rte',
      'filename' => 'modSystemSetting/4930cc10e4b1394ec497325bfe615834.vehicle',
      'namespace' => 'fred',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aa786b7aea32eb09f0fa28f4f4846092',
      'native_key' => 'fred.element_group_sort',
      'filename' => 'modSystemSetting/8f07ac9b5eb3f095770e2e257596fc91.vehicle',
      'namespace' => 'fred',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ebe3e7c5fa321c4153eb3a0466191c2f',
      'native_key' => 'fred.blueprint_category_sort',
      'filename' => 'modSystemSetting/fe224f4c63755cb7ff5732f57e82d936.vehicle',
      'namespace' => 'fred',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '920df847202310ad2b03f63ef13bffba',
      'native_key' => 'fred.blueprint_sort',
      'filename' => 'modSystemSetting/e726c9057ca36b51e8cf12500d0774a3.vehicle',
      'namespace' => 'fred',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '784e378ebe7d618b85617e2b34602857',
      'native_key' => 'fred.default_element',
      'filename' => 'modSystemSetting/fb65055f0c3287a1940abd1ed6af303c.vehicle',
      'namespace' => 'fred',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '98b1bdf8bbf374a37ac825ac47e8ab51',
      'native_key' => NULL,
      'filename' => 'modCategory/3f895762c0fb9fb26cb18ece6508d976.vehicle',
      'namespace' => 'fred',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '38f1f240b95f65d08682e465ec548dff',
      'native_key' => 'fred.menu.fred',
      'filename' => 'modMenu/4f88bd3d55744766f3c43a04c1ebea3b.vehicle',
      'namespace' => 'fred',
    ),
  ),
);