<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'The MIT License (MIT)

Copyright (c) 2018 MODX, LLC

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.',
    'readme' => '---------------------------------------
Fred
---------------------------------------
Version: 1.0.0-beta6
Author: John Peca <john@modx.com>
---------------------------------------',
    'changelog' => 'Changelog for Fred.

1.0.0 beta6
==============
- Add theme directory for theme\'s assets
- Use new placeholder {{theme_dir}} when generating elements & blueprints images
- Add placeholder for templates & chunk [[++fred.theme_dir]] to reference theme directory
- Add Build theme action (creates a transport package from theme)
- Consolidate tabs in the CMP
- Generate screenshot for complete blueprint from page preview (instead of from Fred\'s view)
- Remove deprecated system settings
- Add help buttons to CMP and frontend (under "More" sidebar)
- Remove theme-template relation when template is deleted
- When deleting theme, give an option to delete theme directory
- When duplicating theme, give an options to duplicate theme\'s objects and theme directory
- Fix selecting option set from current theme in element\'s quick update window and update panel 

1.0.0 beta5
==============
- Lower dependencies to support PHP 5.6+
- Security fixes

1.0.0 beta4
==============
- Add CMP for Elements, RTE Configs, Option Sets, Themes
- Add UUID for elements, element categories, blueprints and blueprint categories
- Make blueprint\'s & element\'s image not required and fill it with placeholder image if empty
- TVs as a target & in Page Settings

1.0.0 beta3
==============
- Add CMP for Blueprints
- Add blueprints
- Add default image for elements, if none is set

1.0.0 beta2
==============
- Prevent child blocks from remaining active on scroll
- Add context_key check to site tree
- Fixed foreach warning on RenderContent and LoadContent
- Update documentation
- Add ru lexicon
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'c9e890038f9d42f48ffdae71ed06ad20',
      'native_key' => 'fred',
      'filename' => 'modNamespace/2e86a4f28da0a2f47286110eca1c236c.vehicle',
      'namespace' => 'fred',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b8cea24375c28f50c73855ae1a6932b3',
      'native_key' => 'fred.launcher_position',
      'filename' => 'modSystemSetting/852c21d82fb420fd9192af02d21b8853.vehicle',
      'namespace' => 'fred',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '46face05938d536afc7f4eeb58b4698a',
      'native_key' => 'fred.icon_editor',
      'filename' => 'modSystemSetting/51688ae4570a41950e52e9698ea0b7b3.vehicle',
      'namespace' => 'fred',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '762e340fe94583989e23152963b06028',
      'native_key' => 'fred.image_editor',
      'filename' => 'modSystemSetting/abc94168d542c59ca748a9eb201bf49b.vehicle',
      'namespace' => 'fred',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2cfdbda160ca83e8f570a49a3fa3e9d6',
      'native_key' => 'fred.rte',
      'filename' => 'modSystemSetting/ccb459a71c6b797bfa0418e8b07a3d9e.vehicle',
      'namespace' => 'fred',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3410a9fc6e24a44f72fd89e043ce71fe',
      'native_key' => 'fred.element_group_sort',
      'filename' => 'modSystemSetting/264a7d3bb27cce3c4e4b2b8625f9ed28.vehicle',
      'namespace' => 'fred',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0ac350290efec26f81ef88e9e6d4b991',
      'native_key' => 'fred.blueprint_category_sort',
      'filename' => 'modSystemSetting/d36367b45a181fcabb638bef5a2afbbe.vehicle',
      'namespace' => 'fred',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fb133f314114541aafdd5f84d6570912',
      'native_key' => 'fred.blueprint_sort',
      'filename' => 'modSystemSetting/56a39d9a153fe9e2488066c9a0695c94.vehicle',
      'namespace' => 'fred',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '57de1601a95a079382d93f7ec1ae1e9e',
      'native_key' => 'fred.default_element',
      'filename' => 'modSystemSetting/77fa6cd998acc2f0245d4df8a2495ab6.vehicle',
      'namespace' => 'fred',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '5834786b07507d3a0c045280d89116b9',
      'native_key' => NULL,
      'filename' => 'modCategory/220fc147d7e7c3c18853cac23189c9ff.vehicle',
      'namespace' => 'fred',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'b4f3640b3353b2cde2359aaf4ec7eca1',
      'native_key' => 'fred.menu.fred',
      'filename' => 'modMenu/c185e7369ec4cffe137751903d8a9918.vehicle',
      'namespace' => 'fred',
    ),
  ),
);