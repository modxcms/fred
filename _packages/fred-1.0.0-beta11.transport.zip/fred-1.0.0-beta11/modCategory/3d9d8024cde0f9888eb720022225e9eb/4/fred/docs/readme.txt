---------------------------------------
Fred
---------------------------------------
Version: 1.0.0-beta11
Author: John Peca <john@modx.com>
---------------------------------------

UPGRADE NOTES
=======================================
-> beta7
If you defined media sources in option sets, element's markup or options override you'll need to adjust these from media source id to media source name 