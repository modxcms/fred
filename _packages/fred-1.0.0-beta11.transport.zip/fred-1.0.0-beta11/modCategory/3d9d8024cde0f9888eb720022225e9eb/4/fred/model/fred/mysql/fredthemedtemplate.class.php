<?php
/**
 * @package fred
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/fredthemedtemplate.class.php');
class FredThemedTemplate_mysql extends FredThemedTemplate {}
?>