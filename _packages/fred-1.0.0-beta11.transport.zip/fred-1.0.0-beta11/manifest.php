<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'The MIT License (MIT)

Copyright (c) 2018 MODX, LLC

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.',
    'readme' => '---------------------------------------
Fred
---------------------------------------
Version: 1.0.0-beta11
Author: John Peca <john@modx.com>
---------------------------------------

UPGRADE NOTES
=======================================
-> beta7
If you defined media sources in option sets, element\'s markup or options override you\'ll need to adjust these from media source id to media source name ',
    'changelog' => 'Changelog for Fred.

1.0.0 beta11
============
- Removed some of the mystery from building Themes by displaying an alert when the change log, readme or license files were missing. Silence is good for movie watchers—not so much for letting folks know why they can\'t export the Theme they\'ve worked hard on creating. Sorry about that! 
- Fred now opens all links in the Preview mode in a new tab because loading them in the iframe created an undesired Fredception. 
- Fixed initializing javascript when remote Elements are dropped into dropzones. This bodes well for things like galleries and sliders initiated by a document.ready function.
- Fixed loading the Resource Tree with nested Fred Resources.
- Fixed generating preview URLs for unpublished Resources.
- Prevent copying outer HTML from contenteditable Elements, which could lead to serious messes. We don\'t like messes.
- Ensure Elements are loaded in the correct order when Fred initializes, because randomly reordering peoples\' nested content is apparently not a desired feature. 
- Add a new mode to disable/enable Fred, making those final QA chores a lot easier and less click-error prone.
- Automatically set contenteditable to true for all Elements with a data-fred-name attribute. If you don\'t want them editable, you must declare it false. But since this is meant as a front-end editor, this could save a few keystrokes and make learning how to create Elements slightly easier to learn by approximately 4.2%.
- Pass GET params from the page to the render Element endpoint so to make Fred behave properly with things like Tagger.
- Fix the preview window from cutting off because, as it turns out, 51px really does make a difference.

1.0.0 beta10
============
- Supports multiple dropzones thanks to a new custom "Fred Dropzone" Template Variable. 
- A new element_sort system setting determines, shockingly, how Elements are sorted: either by their name or by a rank specified in the Manager component (previously was by ID). Defaults to name.
- Fred didn\'t allow using Snippets in image tag src attributes. Now it does making @reikotec at least 42% more happy. You\'re welcome! 
- Fixed an annoying oversight that broke how Fred-managed content rendered after saving a page in the Manager (which was not very well at all).
- Now you can clone, delete, publish/unpublish and create child pages from the Fred sidebar menu Site option. Click a page name to see the available options. 

1.0.0 beta9
==============
- Fred now supports Permissions and Policies, ticking off the last big 1.0 feature checklist item. Time to thoroughly work over every bit of Fred ahead of its initial public release! 
- The width of the toolbar on small Elements hid important icons. Now it doesn\'t. 
- While mildly entertaining at first, the flashing cycles when hovering the parent Element of nested ones quickly becomes annoying. Fixed.
- You get to see the magical preview soon after clicking the button when generating full-page Blueprints. So much for delayed gratification. 
- Validate the name, version, and release when building a Theme, because themes are cool and it\'s the right thing to do.
- Check `list` policy on media sources so people can\'t rearrange the root-level file system for you.
- Sign every XHR call so that less than scrupulous people don\'t edit—or remove—your site for you.
- Display an error message that explains why trying to download a theme without a transport package doesn\'t work so well.

1.0.0 beta8
==============
- Now with 100% more German. Danke für die Übersetzung.
- Fix HTML generation when saving Fred Resource from the Manager,  which didn\'t work and was a bummer. Now it\'s not.
- Show a loading icon when generating Blueprint screenshots. This helps calm user anxiety over "Didn\'t I just push that button? …" as it can take a few seconds when doing full-page Blueprints.
- Duplicating an image that saved to a TV caused an infinite loop. Inception is good for movies, not for software, so we fixed that.
- Fix toggling fred and fredReadOnly attributes from in the Media Source tab of the Manager page because it\'s the right thing to do.

1.0.0 beta7
==============
- Move elFinder\'s processors under core for better security
- Streamline elFinder buttons shown
- Create a Media Source on Fred installation: /assets
- Add a tab to the Manager component for managing the Media Sources available to Fred
- Fix toggle option setting control when the default value was set to true
- Change referencing Media Sources by ID to Name in option sets and Element markup

1.0.0 beta6
==============
- Add theme directory for theme\'s assets
- Use new placeholder {{theme_dir}} when generating elements & blueprints images
- Add placeholder for templates & chunk [[++fred.theme_dir]] to reference theme directory
- Add Build theme action (creates a transport package from theme)
- Consolidate tabs in the CMP
- Generate screenshot for complete blueprint from page preview (instead of from Fred\'s view)
- Remove deprecated system settings
- Add help buttons to CMP and frontend (under "More" sidebar)
- Remove theme-template relation when template is deleted
- When deleting theme, give an option to delete theme directory
- When duplicating theme, give an options to duplicate theme\'s objects and theme directory
- Fix selecting option set from current theme in element\'s quick update window and update panel 

1.0.0 beta5
==============
- Lower dependencies to support PHP 5.6+
- Security fixes

1.0.0 beta4
==============
- Add CMP for Elements, RTE Configs, Option Sets, Themes
- Add UUID for elements, element categories, blueprints and blueprint categories
- Make blueprint\'s & element\'s image not required and fill it with placeholder image if empty
- TVs as a target & in Page Settings

1.0.0 beta3
==============
- Add CMP for Blueprints
- Add blueprints
- Add default image for elements, if none is set

1.0.0 beta2
==============
- Prevent child blocks from remaining active on scroll
- Add context_key check to site tree
- Fixed foreach warning on RenderContent and LoadContent
- Update documentation
- Add ru lexicon
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'b77c68689a629803dd4ec890feac6805',
      'native_key' => 'fred',
      'filename' => 'modNamespace/626dfd7b4187895cac5d65ea7619c222.vehicle',
      'namespace' => 'fred',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '94c532ecb6206da6fc60c1c44f63ed8d',
      'native_key' => 'fred.launcher_position',
      'filename' => 'modSystemSetting/257a0c096c8605a55e199351f6718a5f.vehicle',
      'namespace' => 'fred',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '02fa05ff1641ce179e2056e780014d9b',
      'native_key' => 'fred.icon_editor',
      'filename' => 'modSystemSetting/9b5e3b32952d7df290979be6a252e62a.vehicle',
      'namespace' => 'fred',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a4c21bf6acab31da9b4817d4bc404140',
      'native_key' => 'fred.image_editor',
      'filename' => 'modSystemSetting/038260cf03675129a0943fe9da79a2f4.vehicle',
      'namespace' => 'fred',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b6815df91c62892c0dbf58fae596c7d0',
      'native_key' => 'fred.rte',
      'filename' => 'modSystemSetting/fd94b16559217d66d6b32cf562281ef2.vehicle',
      'namespace' => 'fred',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c53592a5431be2ad1c33024b91c860af',
      'native_key' => 'fred.element_group_sort',
      'filename' => 'modSystemSetting/de295e49e5527d17760a071c88304007.vehicle',
      'namespace' => 'fred',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7ada2e0ca648588607c8e77d5e829973',
      'native_key' => 'fred.element_sort',
      'filename' => 'modSystemSetting/1ba6870235d114aee04e077f27b53fe5.vehicle',
      'namespace' => 'fred',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '120c8502f9a3c8a483a57826b06cc473',
      'native_key' => 'fred.blueprint_category_sort',
      'filename' => 'modSystemSetting/f90f62b9d0284143756f78fe2591e002.vehicle',
      'namespace' => 'fred',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f907d70fa2d7e4cc45247691b2d9f757',
      'native_key' => 'fred.blueprint_sort',
      'filename' => 'modSystemSetting/1a36a8fd332965e99a6cd930795e54aa.vehicle',
      'namespace' => 'fred',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '71f47b93213812bceafa6cee5fb8307b',
      'native_key' => 'fred.default_element',
      'filename' => 'modSystemSetting/68556fb8f2a8a917c17d113a2566ad8b.vehicle',
      'namespace' => 'fred',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e3182e99ebbdd2901732e98bcf8799f7',
      'native_key' => 'fred.secret',
      'filename' => 'modSystemSetting/b7fc1f02e3ba5a9d9729673e3e4f92eb.vehicle',
      'namespace' => 'fred',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'f96a29b85c2efa97196e0a734a5bbba2',
      'native_key' => NULL,
      'filename' => 'modCategory/3d9d8024cde0f9888eb720022225e9eb.vehicle',
      'namespace' => 'fred',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '4e56c11cbffcdf9a70477323d8441706',
      'native_key' => 'fred.menu.fred',
      'filename' => 'modMenu/71972d407de4b59f7173a077c998c712.vehicle',
      'namespace' => 'fred',
    ),
  ),
);