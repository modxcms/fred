<?php
/**
 * @package fred
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/fredelement.class.php');
class FredElement_mysql extends FredElement {}
?>