<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'The MIT License (MIT)

Copyright (c) 2018 MODX, LLC

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.',
    'readme' => '---------------------------------------
Fred
---------------------------------------
Version: 1.0.0-beta4
Author: John Peca <john@modx.com>
---------------------------------------',
    'changelog' => 'Changelog for Fred.

1.0.0 beta4
==============
- Add CMP for Elements, RTE Configs, Option Sets, Themes
- Add UUID for elements, element categories, blueprints and blueprint categories
- Make blueprint\'s & element\'s image not required and fill it with placeholder image if empty
- TVs as a target & in Page Settings

1.0.0 beta3
==============
- Add CMP for Blueprints
- Add blueprints
- Add default image for elements, if none is set

1.0.0 beta2
==============
- Prevent child blocks from remaining active on scroll
- Add context_key check to site tree
- Fixed foreach warning on RenderContent and LoadContent
- Update documentation
- Add ru lexicon
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '10cc57ebdc3dcb304576e91432c55030',
      'native_key' => 'fred',
      'filename' => 'modNamespace/35baeeb62da0fb83e24fa48ce132cfe1.vehicle',
      'namespace' => 'fred',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2495c15e95e16f4a7d19c045e9b5fc38',
      'native_key' => 'fred.elements_category_id',
      'filename' => 'modSystemSetting/8c06a8b5f7ad62cefb3e909b2a10f442.vehicle',
      'namespace' => 'fred',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ca5f15923542f3d072c7c88686029ebf',
      'native_key' => 'fred.template_ids',
      'filename' => 'modSystemSetting/932f4f3f04efc429c8a4d4fcd539b9a1.vehicle',
      'namespace' => 'fred',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f5a0b2bf37b972b78a020c030161ffc5',
      'native_key' => 'fred.launcher_position',
      'filename' => 'modSystemSetting/1cce35f347dc50c1f88b7218de64593c.vehicle',
      'namespace' => 'fred',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7b684aaad15d0b02f2989bd1f774dfb9',
      'native_key' => 'fred.icon_editor',
      'filename' => 'modSystemSetting/2a2c31c872f0a74ab6b7952841978fd9.vehicle',
      'namespace' => 'fred',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0526a441a1a999e07d1922747fe55103',
      'native_key' => 'fred.image_editor',
      'filename' => 'modSystemSetting/1af5887c01030e87b4c4ec5e12301d7c.vehicle',
      'namespace' => 'fred',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ac005e6366ae99c946ceea461d8d3e51',
      'native_key' => 'fred.rte',
      'filename' => 'modSystemSetting/4fb1986527abf7d25c2568f6002c0e67.vehicle',
      'namespace' => 'fred',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a5d794c301afa8fcb04a85dab7c88b82',
      'native_key' => 'fred.rte_config',
      'filename' => 'modSystemSetting/326ebb571e0bc05a85635d59a34f22c1.vehicle',
      'namespace' => 'fred',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e592301818d6f5e9586a492e5d68c2c9',
      'native_key' => 'fred.element_group_sort',
      'filename' => 'modSystemSetting/b1fd5a74c36dc411b6dcb1142e1c4187.vehicle',
      'namespace' => 'fred',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fcf98b7c93a3966ce705f3c546d132bf',
      'native_key' => 'fred.blueprint_category_sort',
      'filename' => 'modSystemSetting/0c895954a78f87fb512a3bb7242b08e6.vehicle',
      'namespace' => 'fred',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2da459b44037cbf576572c35491ec4a0',
      'native_key' => 'fred.blueprint_sort',
      'filename' => 'modSystemSetting/b1b7e96315e638d625413b095c949a80.vehicle',
      'namespace' => 'fred',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '441b9355b8f6cdf7f594ca16e8c10b22',
      'native_key' => 'fred.default_element',
      'filename' => 'modSystemSetting/ea7552372470b6439a0375cdf2284937.vehicle',
      'namespace' => 'fred',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '383db63b309da26eda54e7ceb3569f60',
      'native_key' => 'fred.generated_images_path',
      'filename' => 'modSystemSetting/60654b754b653f4ddec43a5cb0ec6555.vehicle',
      'namespace' => 'fred',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a5533bfe5a4ca2cb8366f64e991476c9',
      'native_key' => 'fred.generated_images_url',
      'filename' => 'modSystemSetting/4815061c6440c68b0e90d4360d7c0081.vehicle',
      'namespace' => 'fred',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'bb8e595aaf3179c94e704e6347c6928b',
      'native_key' => NULL,
      'filename' => 'modCategory/f44def6e08e2621aebabefcffc2669cb.vehicle',
      'namespace' => 'fred',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '361508814e897389844e86b0213f2452',
      'native_key' => 'fred.menu.fred',
      'filename' => 'modMenu/b449b724f76ca9353560ddee51c45a73.vehicle',
      'namespace' => 'fred',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '430bdb5ef5162f665453dcbcf5977b50',
      'native_key' => 'fred.menu.refresh',
      'filename' => 'modMenu/64b650d3bba5cf739524ca3061fd8cad.vehicle',
      'namespace' => 'fred',
    ),
  ),
);