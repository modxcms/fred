<?php
/**
 * @property int $resource
 * @property int $element
 * @property string $content
 * 
 * @property modResource $Resource
 * @property FredElement $Element
 * @package fred
 */
class FredCache extends xPDOObject {}