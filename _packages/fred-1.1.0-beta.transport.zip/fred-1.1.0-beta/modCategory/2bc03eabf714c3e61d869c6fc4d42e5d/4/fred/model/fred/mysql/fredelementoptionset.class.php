<?php
/**
 * @package fred
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/fredelementoptionset.class.php');
class FredElementOptionSet_mysql extends FredElementOptionSet {}
?>