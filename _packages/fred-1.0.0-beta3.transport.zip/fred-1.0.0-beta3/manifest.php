<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'The MIT License (MIT)

Copyright (c) 2018 MODX, LLC

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.',
    'readme' => '---------------------------------------
Fred
---------------------------------------
Version: 0.1.3-alpha
Author: John Peca <john@modx.com>
---------------------------------------',
    'changelog' => 'Changelog for Fred.

1.0.0 beta3
==============
- Add CMP for Blueprints
- Add blueprints
- Add default image for elements, if none is set

1.0.0 beta2
==============
- Prevent child blocks from remaining active on scroll
- Add context_key check to site tree
- Fixed foreach warning on RenderContent and LoadContent
- Update documentation
- Add ru lexicon
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'c992d322c295736556fc577bc8b4f93b',
      'native_key' => 'fred',
      'filename' => 'modNamespace/05ad32d383bee2fc096b403979c15923.vehicle',
      'namespace' => 'fred',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e9cd2faac04f1633e3c7dcf2dc9992ee',
      'native_key' => 'fred.elements_category_id',
      'filename' => 'modSystemSetting/6f5b49f4bb69eec1584f7f9b081e3396.vehicle',
      'namespace' => 'fred',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fc1e9f1fb5f8dae5559c854dac497f3e',
      'native_key' => 'fred.template_ids',
      'filename' => 'modSystemSetting/2f1b0935ebffb67d5122bec16beeb849.vehicle',
      'namespace' => 'fred',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4df6402ccd0761d4e767d0f7bfe7a77f',
      'native_key' => 'fred.launcher_position',
      'filename' => 'modSystemSetting/268e54b6d48a2bcceac0776a745bfc19.vehicle',
      'namespace' => 'fred',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cfd7df25e08224f0ccb33f82d8214127',
      'native_key' => 'fred.icon_editor',
      'filename' => 'modSystemSetting/4f2d2ff7230a49cbe8f4c2481255c2f9.vehicle',
      'namespace' => 'fred',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '69cd7e42dfbc60882aa920bbbbf72f5d',
      'native_key' => 'fred.image_editor',
      'filename' => 'modSystemSetting/ee4b2ef809eb3cb9e4c92e3ce0a4c792.vehicle',
      'namespace' => 'fred',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bf57d52a436726b4cbf9450a38d2caad',
      'native_key' => 'fred.rte',
      'filename' => 'modSystemSetting/b0af69149d5379e51fd824a641cc0839.vehicle',
      'namespace' => 'fred',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd98580161aafb170a4407bbdebe12ee0',
      'native_key' => 'fred.rte_config',
      'filename' => 'modSystemSetting/974132b9263bd56eaf1d8dbdcc8757e7.vehicle',
      'namespace' => 'fred',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd8ed03e0232da5838cc2e3955bf96e5f',
      'native_key' => 'fred.element_group_sort',
      'filename' => 'modSystemSetting/d70ba5f00274b0740f6d072e420cf41a.vehicle',
      'namespace' => 'fred',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f253cbcdd7cbf5d660bdb8a968b1c10d',
      'native_key' => 'fred.blueprint_category_sort',
      'filename' => 'modSystemSetting/cf58016b8b69efc5ca276313ede35a60.vehicle',
      'namespace' => 'fred',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cd74ec9eef02a4810724e32f5bdb3fc7',
      'native_key' => 'fred.blueprint_sort',
      'filename' => 'modSystemSetting/ea7d70cf356e8161b3a03b97ff5d9680.vehicle',
      'namespace' => 'fred',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f99202f17c8f25ddfb76ccbfcd09f8e9',
      'native_key' => 'fred.default_element',
      'filename' => 'modSystemSetting/f14d08beb3f7913673045a238f83bbff.vehicle',
      'namespace' => 'fred',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '59ec470c951c7ccabaffee2535eef37d',
      'native_key' => 'fred.generated_images_path',
      'filename' => 'modSystemSetting/ada918a79ff43453b8f5bae957ef9929.vehicle',
      'namespace' => 'fred',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9ea210730ef9d3426731cf52a9765685',
      'native_key' => 'fred.generated_images_url',
      'filename' => 'modSystemSetting/59f52f64f6d35ea3318ac4827eb22813.vehicle',
      'namespace' => 'fred',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'bea6f55401bcd1b885c613b28ceda752',
      'native_key' => NULL,
      'filename' => 'modCategory/271a072eb092b04b97ccb3a3b613da60.vehicle',
      'namespace' => 'fred',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'd75b336c58dfcab7084089aa515a4a3e',
      'native_key' => 'fred',
      'filename' => 'modMenu/73e4804ec3507b336424a5c979bd5df0.vehicle',
      'namespace' => 'fred',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '1a741577d929ce9b2bdfcd560fbfc1bb',
      'native_key' => 'fred.menu.blueprints',
      'filename' => 'modMenu/7ffa3eff5dbc463dd648be23c5b91dff.vehicle',
      'namespace' => 'fred',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '0d22e31c9aa7b9c3bbd067e125e35d81',
      'native_key' => 'fred.menu.refresh',
      'filename' => 'modMenu/dd5f1633f88c577e5e2bfced4aec7f0e.vehicle',
      'namespace' => 'fred',
    ),
  ),
);