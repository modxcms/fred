<?php
/**
 * @property int $theme
 * @property int $template
 * 
 * @property FredTheme $Theme
 * @property modTemplate $Template
 * 
 * @package fred
 */
class FredThemedTemplate extends xPDOObject {}