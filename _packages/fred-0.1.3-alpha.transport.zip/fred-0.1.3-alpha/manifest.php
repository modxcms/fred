<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'The MIT License (MIT)

Copyright (c) 2016 Liad Yosef

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => '---------------------------------------
Fred
---------------------------------------
Version: 0.1.3-alpha
Author: John Peca <john@modx.com>
---------------------------------------',
    'changelog' => 'Changelog for Fred.

',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '8e3732a0dbe24bfac9cb087b799e1871',
      'native_key' => 'fred',
      'filename' => 'modNamespace/84cbf3c6c0d462403dc8f41375965814.vehicle',
      'namespace' => 'fred',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f227a141d695edfd4d67e0a6e2fdece2',
      'native_key' => 'fred.elements_category_id',
      'filename' => 'modSystemSetting/dad4b0741558ca5223b25836ee5efc79.vehicle',
      'namespace' => 'fred',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1f7451189b1647bb8722faa707efa306',
      'native_key' => 'fred.template_ids',
      'filename' => 'modSystemSetting/f518bce4777c3c4b20b77c2002af8546.vehicle',
      'namespace' => 'fred',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '67d9726ac417a56b59c0baa4a132f68a',
      'native_key' => 'fred.launcher_position',
      'filename' => 'modSystemSetting/164ff7c80d56e559683259004349fe4f.vehicle',
      'namespace' => 'fred',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2d0c5849db6a7bf38b74a9ba77b2dc39',
      'native_key' => 'fred.icon_editor',
      'filename' => 'modSystemSetting/20b794fd50cb05071aa29549da5232b3.vehicle',
      'namespace' => 'fred',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '74e57cc54feb0183c097500338581860',
      'native_key' => 'fred.image_editor',
      'filename' => 'modSystemSetting/ff3f0b9d1788f9a6233a887cdd398bd6.vehicle',
      'namespace' => 'fred',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2c9061cb46fab5b664a8e0938bf15626',
      'native_key' => 'fred.rte',
      'filename' => 'modSystemSetting/24c52e0f317cf3ce8b82896b2b6da692.vehicle',
      'namespace' => 'fred',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '69a41502a1cb3cf1757a7e355f03454c',
      'native_key' => 'fred.rte_config',
      'filename' => 'modSystemSetting/df3a0ff9d93f100852aa37cadb75b4f0.vehicle',
      'namespace' => 'fred',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cbabc5254a1b3489429f14f8059258cb',
      'native_key' => 'fred.element_group_sort',
      'filename' => 'modSystemSetting/5b565f2d489ef46452c590f7b4fc83b2.vehicle',
      'namespace' => 'fred',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '79645abd35c34e541ed422bc68fb5e31',
      'native_key' => 'fred.default_element',
      'filename' => 'modSystemSetting/9f92c44af0a0558ec97a3e0a788e8466.vehicle',
      'namespace' => 'fred',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'c7de6bfc28b43581f882223313820e30',
      'native_key' => NULL,
      'filename' => 'modCategory/15851ec5d87f2ad8a0a5d316ff3b9b03.vehicle',
      'namespace' => 'fred',
    ),
  ),
);