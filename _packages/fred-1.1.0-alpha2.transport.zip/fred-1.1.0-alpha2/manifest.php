<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'The MIT License (MIT)

Copyright (c) 2018 MODX, LLC

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.',
    'readme' => '---------------------------------------
Fred
---------------------------------------
Version: 1.0.0
Author: John Peca <john@modx.com>
---------------------------------------
Fred is a visual drag-and-drop front-end editor for MODX Revolution.

Documentation: https://modxcms.github.io/fred

Fred Extras, including ready-to-use Themes: https://modx.com/extras/browse/?search=fred


UPGRADE NOTES
=======================================
If you are upgrading from a previous release to the following versions, please note the important changes:

------------
-> rc1 
------------
Make sure all Themes are named uniquely, and any Elements, Blueprints, Element categories, or Blueprint categories within a Themes likewise have unique names. You can share names across Themes, except for the Theme name itself.

------------
-> beta7
------------
If you defined a Media Sources in Option Sets, in Element markup, or an Options Override, you need to adjust these from using the Media Source ID to the Media Source name.
',
    'changelog' => 'Changelog for Fred.

1.0.0 pl
============
- Gitify support added for using version control in your workflow
- Scrolling issues have been fixed in Chrome and Safari
- TVs no longer need to be Fred enabled in order to be saved to
- New element setting added for file types and text areas
- Fixed the search for the page type element setting
- Fixed an issue for element settings with the default value of 0
- Fixed a visibility issue with adding new pages
- Fixed toggle boxes overlapping drop menus
- Improved context support for frontend endpoints
- Grids now refresh when a category is deleted in the CMP
- Fixed publish on date when saving a resource from Fred
- Parent select boxes now respect "list" policy
- Added translations for Dutch, German and Russian languages

1.0.0 rc1
============
- Each theme now gets its own defaut_element, which is handy when migrating content from non-Fred sites into Fred.
- Pages were sometimes hiding from the front end, which made it difficult to work on sites. Now it\'s a lot easier, and we have outlawed games of hide and seek going forward.
- When switching Themes, pages can have Elements from other themes, which can lead to Bad Things™. Now we warn when this has happened so you can prevent future frustration.
- Elements, Blueprints, Element categories, Blueprint categories and Themes now have to have unique names. This is so multiple Themes don\'t co-mingle their assets with a potentially messy outcome.
- Found a few places where XHR errors had been left as static strings. Now they can be translated for better feedback if things go awry.

1.0.0 beta12
============
- Fix showing enable Fred button for users without permissions
- Fix double sidebar in preview mode

1.0.0 beta11
============
- Removed some of the mystery from building Themes by displaying an alert when the change log, readme or license files were missing. Silence is good for movie watchers—not so much for letting folks know why they can\'t export the Theme they\'ve worked hard on creating. Sorry about that! 
- Fred now opens all links in the Preview mode in a new tab because loading them in the iframe created an undesired Fredception. 
- Fixed initializing javascript when remote Elements are dropped into dropzones. This bodes well for things like galleries and sliders initiated by a document.ready function.
- Fixed loading the Resource Tree with nested Fred Resources.
- Fixed generating preview URLs for unpublished Resources.
- Prevent copying outer HTML from contenteditable Elements, which could lead to serious messes. We don\'t like messes.
- Ensure Elements are loaded in the correct order when Fred initializes, because randomly reordering peoples\' nested content is apparently not a desired feature. 
- Add a new mode to disable/enable Fred, making those final QA chores a lot easier and less click-error prone.
- Automatically set contenteditable to true for all Elements with a data-fred-name attribute. If you don\'t want them editable, you must declare it false. But since this is meant as a front-end editor, this could save a few keystrokes and make learning how to create Elements slightly easier to learn by approximately 4.2%.
- Pass GET params from the page to the render Element endpoint so to make Fred behave properly with things like Tagger.
- Fix the preview window from cutting off because, as it turns out, 51px really does make a difference.

1.0.0 beta10
============
- Supports multiple dropzones thanks to a new custom "Fred Dropzone" Template Variable. 
- A new element_sort system setting determines, shockingly, how Elements are sorted: either by their name or by a rank specified in the Manager component (previously was by ID). Defaults to name.
- Fred didn\'t allow using Snippets in image tag src attributes. Now it does making @reikotec at least 42% more happy. You\'re welcome! 
- Fixed an annoying oversight that broke how Fred-managed content rendered after saving a page in the Manager (which was not very well at all).
- Now you can clone, delete, publish/unpublish and create child pages from the Fred sidebar menu Site option. Click a page name to see the available options. 

1.0.0 beta9
==============
- Fred now supports Permissions and Policies, ticking off the last big 1.0 feature checklist item. Time to thoroughly work over every bit of Fred ahead of its initial public release! 
- The width of the toolbar on small Elements hid important icons. Now it doesn\'t. 
- While mildly entertaining at first, the flashing cycles when hovering the parent Element of nested ones quickly becomes annoying. Fixed.
- You get to see the magical preview soon after clicking the button when generating full-page Blueprints. So much for delayed gratification. 
- Validate the name, version, and release when building a Theme, because themes are cool and it\'s the right thing to do.
- Check `list` policy on media sources so people can\'t rearrange the root-level file system for you.
- Sign every XHR call so that less than scrupulous people don\'t edit—or remove—your site for you.
- Display an error message that explains why trying to download a theme without a transport package doesn\'t work so well.

1.0.0 beta8
==============
- Now with 100% more German. Danke für die Übersetzung.
- Fix HTML generation when saving Fred Resource from the Manager,  which didn\'t work and was a bummer. Now it\'s not.
- Show a loading icon when generating Blueprint screenshots. This helps calm user anxiety over "Didn\'t I just push that button? …" as it can take a few seconds when doing full-page Blueprints.
- Duplicating an image that saved to a TV caused an infinite loop. Inception is good for movies, not for software, so we fixed that.
- Fix toggling fred and fredReadOnly attributes from in the Media Source tab of the Manager page because it\'s the right thing to do.

1.0.0 beta7
==============
- Move elFinder\'s processors under core for better security
- Streamline elFinder buttons shown
- Create a Media Source on Fred installation: /assets
- Add a tab to the Manager component for managing the Media Sources available to Fred
- Fix toggle option setting control when the default value was set to true
- Change referencing Media Sources by ID to Name in option sets and Element markup

1.0.0 beta6
==============
- Add theme directory for theme\'s assets
- Use new placeholder {{theme_dir}} when generating elements & blueprints images
- Add placeholder for templates & chunk [[++fred.theme_dir]] to reference theme directory
- Add Build theme action (creates a transport package from theme)
- Consolidate tabs in the CMP
- Generate screenshot for complete blueprint from page preview (instead of from Fred\'s view)
- Remove deprecated system settings
- Add help buttons to CMP and frontend (under "More" sidebar)
- Remove theme-template relation when template is deleted
- When deleting theme, give an option to delete theme directory
- When duplicating theme, give an options to duplicate theme\'s objects and theme directory
- Fix selecting option set from current theme in element\'s quick update window and update panel 

1.0.0 beta5
==============
- Lower dependencies to support PHP 5.6+
- Security fixes

1.0.0 beta4
==============
- Add CMP for Elements, RTE Configs, Option Sets, Themes
- Add UUID for elements, element categories, blueprints and blueprint categories
- Make blueprint\'s & element\'s image not required and fill it with placeholder image if empty
- TVs as a target & in Page Settings

1.0.0 beta3
==============
- Add CMP for Blueprints
- Add blueprints
- Add default image for elements, if none is set

1.0.0 beta2
==============
- Prevent child blocks from remaining active on scroll
- Add context_key check to site tree
- Fixed foreach warning on RenderContent and LoadContent
- Update documentation
- Add ru lexicon
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'e36d5e12029e9df39069f22ece32d6c6',
      'native_key' => 'fred',
      'filename' => 'modNamespace/3685186f8e8592086fe942ee8da3bde9.vehicle',
      'namespace' => 'fred',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f048eb6cf66c230227cda6d3e86f4d26',
      'native_key' => 'fred.launcher_position',
      'filename' => 'modSystemSetting/30eb9bfba058d5a75b07d259ea5739ec.vehicle',
      'namespace' => 'fred',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dd4f863f0fa35b3edc245d1afc63e783',
      'native_key' => 'fred.icon_editor',
      'filename' => 'modSystemSetting/504d69aec664044ef5400a2cd63dd003.vehicle',
      'namespace' => 'fred',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c67c191583d3d51ab1a4eee46864183c',
      'native_key' => 'fred.image_editor',
      'filename' => 'modSystemSetting/fe8043932f51188c0cc6db547b25ae95.vehicle',
      'namespace' => 'fred',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a8bb71b03aad521e145dc5a573eb68e3',
      'native_key' => 'fred.rte',
      'filename' => 'modSystemSetting/4687200984613719e84bb71dd0a05e9d.vehicle',
      'namespace' => 'fred',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd90ab41d79b2df25e152cd948ba1c27c',
      'native_key' => 'fred.element_group_sort',
      'filename' => 'modSystemSetting/8ef21ddb71c8fedfa5812275e6ec9d5b.vehicle',
      'namespace' => 'fred',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '14efc28372f1b4b0e86dd9eec87b4e4c',
      'native_key' => 'fred.element_sort',
      'filename' => 'modSystemSetting/368d9f795c5debe592200a324fd4dce2.vehicle',
      'namespace' => 'fred',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0e9cc615d00672db6787ae9d5eb1226e',
      'native_key' => 'fred.blueprint_category_sort',
      'filename' => 'modSystemSetting/47a2068266e3688e973437af6f781f76.vehicle',
      'namespace' => 'fred',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4a52bb9aa3d934b953c4960a0e228dc7',
      'native_key' => 'fred.blueprint_sort',
      'filename' => 'modSystemSetting/132d5194e82efc4c0fe422d597fee218.vehicle',
      'namespace' => 'fred',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ec9db355a77b5a26a095249542f13c71',
      'native_key' => 'fred.secret',
      'filename' => 'modSystemSetting/7ebc8dd70c3f9e913fa0398ebd9508bd.vehicle',
      'namespace' => 'fred',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1c63219fbef87efbebbd46f1948504a4',
      'native_key' => 'fred.active_class',
      'filename' => 'modSystemSetting/48b010418bf8152eecb524f7c34dedab.vehicle',
      'namespace' => 'fred',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'ece4dfb52f8cf668fa7670f1ebe4b8ba',
      'native_key' => NULL,
      'filename' => 'modCategory/cb89d1fb8d11b3d8a42f685a67e290bd.vehicle',
      'namespace' => 'fred',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '9b5eedde475dd8eb4857e54134a0c3f3',
      'native_key' => 'fred.menu.fred',
      'filename' => 'modMenu/a8d12d6ac9b2dcd7895cf7fbcb80ec53.vehicle',
      'namespace' => 'fred',
    ),
  ),
);