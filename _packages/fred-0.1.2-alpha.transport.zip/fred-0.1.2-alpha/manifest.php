<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => '
The MIT License (MIT)

Copyright (c) 2018 MODX, LLC

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.',
    'readme' => '---------------------------------------
Fred
---------------------------------------
Version: 0.1.0
Author: John Peca <john@modx.com>
---------------------------------------',
    'changelog' => 'Changelog for Fred.

Fred 0.1.0
==============
- Initial release.',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'd186b403d23d2b81d71faa4df6a31b3b',
      'native_key' => 'fred',
      'filename' => 'modNamespace/b6e1f9b1cbe3b63778915c56bf73c06d.vehicle',
      'namespace' => 'fred',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0e3bd2882dc82b6afb26e7336909f9a8',
      'native_key' => 'fred.elements_category_id',
      'filename' => 'modSystemSetting/cec39b926c86ba5126dc081057bc0956.vehicle',
      'namespace' => 'fred',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fcc50c5b355da163ff55071402dc08ea',
      'native_key' => 'fred.template_ids',
      'filename' => 'modSystemSetting/59bff3c602ec1fef764acd35c2bf1f3c.vehicle',
      'namespace' => 'fred',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6bd82559b08140deee9910bd1e7e3dc0',
      'native_key' => 'fred.launcher_position',
      'filename' => 'modSystemSetting/4056b4e114dd44bc4630ac1b8816e0d1.vehicle',
      'namespace' => 'fred',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '16098a46fc149892df2c7aa5ab010767',
      'native_key' => 'fred.icon_editor',
      'filename' => 'modSystemSetting/17cb4ec06d7bc67e78838b3e64652eae.vehicle',
      'namespace' => 'fred',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '822a5a9f1bac7ba5fb16f6b1adafebbf',
      'native_key' => 'fred.image_editor',
      'filename' => 'modSystemSetting/495d3a20a60be449253473f12397dcf5.vehicle',
      'namespace' => 'fred',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7dbfdf09637f38de4e2116375071c176',
      'native_key' => 'fred.rte',
      'filename' => 'modSystemSetting/942d32cdc8348cb6df39615bd09dc575.vehicle',
      'namespace' => 'fred',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '242f202ba060dc9600296eccc476fb20',
      'native_key' => 'fred.rte_config',
      'filename' => 'modSystemSetting/79e88fb21068eb2d577711cf68c795dc.vehicle',
      'namespace' => 'fred',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2035c6b68eb6d26e7dbbe48b72e71b8c',
      'native_key' => 'fred.element_group_sort',
      'filename' => 'modSystemSetting/ca06b9fc492c8d5989b2eb8a7ee68e31.vehicle',
      'namespace' => 'fred',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'd2fe7a859dec5268a4b8a63d71036379',
      'native_key' => NULL,
      'filename' => 'modCategory/4ee2e0c1a4e2fde0aa52fd1398e0995a.vehicle',
      'namespace' => 'fred',
    ),
  ),
);