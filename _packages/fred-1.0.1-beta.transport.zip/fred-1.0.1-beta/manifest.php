<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'The MIT License (MIT)

Copyright (c) 2018 MODX, LLC

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => '---------------------------------------
Fred
---------------------------------------
Version: 0.1.3-alpha
Author: John Peca <john@modx.com>
---------------------------------------',
    'changelog' => 'Changelog for Fred.

1.0.1 beta
==============
- Prevent child blocks from remaining active on scroll
- Add context_key check to site tree
- Fixed foreach warning on RenderContent and LoadContent
- Update documentation
- Add ru lexicon
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'c0c8787084cfa09f0a807a1bb65494fb',
      'native_key' => 'fred',
      'filename' => 'modNamespace/b301a20ebcaaaf1e2d26ffbb05ac487e.vehicle',
      'namespace' => 'fred',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '19c9ea1b97aace97b7a0d32e70991191',
      'native_key' => 'fred.elements_category_id',
      'filename' => 'modSystemSetting/cd3622cc6dbcc0fe58340fa5fbb040b2.vehicle',
      'namespace' => 'fred',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7b82eb11b779c844530ac5a3f16e5422',
      'native_key' => 'fred.template_ids',
      'filename' => 'modSystemSetting/ffb5cf3edaa2be188ae708df65168d23.vehicle',
      'namespace' => 'fred',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f8b3670bd9d3531e35190fc8528371d8',
      'native_key' => 'fred.launcher_position',
      'filename' => 'modSystemSetting/eacf413886066ab6f3468972f6c177f5.vehicle',
      'namespace' => 'fred',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '49624949b5723c859fc85b93081eba34',
      'native_key' => 'fred.icon_editor',
      'filename' => 'modSystemSetting/48cecb098149b289b5d0ffc75dc5a59a.vehicle',
      'namespace' => 'fred',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd8189be966fc28d3290de3444236e7e9',
      'native_key' => 'fred.image_editor',
      'filename' => 'modSystemSetting/2a53a9ad9f564b8123ad8eef22559a8d.vehicle',
      'namespace' => 'fred',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'da951edd52960e0aa7200f71e013938b',
      'native_key' => 'fred.rte',
      'filename' => 'modSystemSetting/9df657483c44e90ef7e13d91f6a87d54.vehicle',
      'namespace' => 'fred',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4042642bfe17bf91be7301bcf995a2f6',
      'native_key' => 'fred.rte_config',
      'filename' => 'modSystemSetting/8f2da6b74dbf8f52ecb95a895cfd487c.vehicle',
      'namespace' => 'fred',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd8d4d553a976d49cacda4d8467c21b78',
      'native_key' => 'fred.element_group_sort',
      'filename' => 'modSystemSetting/2f22ec69664e72af71935ff3efe98a07.vehicle',
      'namespace' => 'fred',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1ae2ddcb3109c84b1eb04d30e8132ca2',
      'native_key' => 'fred.default_element',
      'filename' => 'modSystemSetting/697325e98363d76b1f69a742879aa7d2.vehicle',
      'namespace' => 'fred',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'c498b85761345778d6550fedb69a20a6',
      'native_key' => NULL,
      'filename' => 'modCategory/4a895df2893c407043f861635aa815a2.vehicle',
      'namespace' => 'fred',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '8301dcc31c19bee5cb7d1d862af53786',
      'native_key' => 'fred.refresh',
      'filename' => 'modMenu/f64621dcea15c6b7b1556f2a4406738f.vehicle',
      'namespace' => 'fred',
    ),
  ),
);